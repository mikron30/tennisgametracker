# Second rebuilt ball model ? 2026-10-06

The first rebuilt candidate (`../ball_patch_model_20261006_candidate.pt`) trained only on daytime examples and ranked true nighttime centers first in 29/40 cases. It exceeded 0.985 on 2/58 reviewed false candidates. It is retained as an experimental baseline.

This dataset adds the explicitly reviewed nighttime examples to training and reserves the October 5 recording as a fresh held-out evaluation video.

- Training: October 3 daytime and October 1 nighttime; 171 reviewed ball patches (11 difficult), 36 representative hard-negative patches.
- Validation: October 5 nighttime; 49 reviewed ball patches (9 difficult), 40 hard negatives. Entire videos remain separate with seed 42.
- Full reviewed index: 220 positives and 120 hard negatives. The frozen training snapshot keeps all 22 daytime negatives and 14 representative nighttime negatives, reducing repeated wall/fence patches. All October 5 validation negatives are retained. Exact sampling decisions are in `training_negative_selection.json`; all original reviews remain in `ball_ai_reviewed.sqlite`.
- Images retain original source resolution in 512px contextual crops; label coordinates are local to the crops, model inputs are 96px. Original coordinates and zero-based frame numbers are recorded in `unreviewed_candidates.json`.
- October 1/3 image paths reference the sibling `../rebuild_20261006_v5/images` directory. Preserve BOTH rebuilt dataset folders, the model files, and source recordings when moving computers. Remap absolute SQLite/image/video paths after moving.
- Model: `../ball_patch_model_20261006_candidate_v2.pt`. Spatial center-aware CNN, seed 42 for torch/NumPy/split, 8 epochs, batch size 32, DirectML (some unsupported training operators fall back to CPU).
- Frozen database: `training_snapshot.sqlite`. Training log/report and held-out evaluation report are saved alongside this README.
- Tracker runtime promotion has not been performed. A full video/scoring regression is required before changing the runtime default.

To reproduce with a NEW candidate filename, use the dedicated Python 3.10 environment and the frozen database:

```powershell
.tools\ball-ai-venv310\Scripts\python.exe ball_local_ai.py train --database metadata/ball_dataset/rebuild_20261006_v6/training_snapshot.sqlite --model metadata/ball_dataset/NEW_CANDIDATE.pt --epochs 8 --batch-size 32 --samples 6000 --seed 42
.tools\ball-ai-venv310\Scripts\python.exe ball_local_ai.py evaluate --database metadata/ball_dataset/rebuild_20261006_v6/training_snapshot.sqlite --model metadata/ball_dataset/NEW_CANDIDATE.pt --samples 6000 --seed 42
```

The saved wrapper sets all training seeds as well. Existing model files and frozen snapshots cannot be overwritten by the pipeline scripts. Do not rerun extraction/import scripts into this frozen directory.

Limitations: this remains a small initial corpus selected for visible balls. Appearance tests do not establish recovery through occlusion, contact, offscreen return, or reliable point scoring. The first candidate and second candidate use different holdouts, so their reported percentages are not a controlled head-to-head comparison.

## Completed results

- Final held-out patch accuracy: 84/89 = 94.4%.
- True center ranked first: 47/49 = 95.9%.
- Difficult true centers ranked first: 8/9 = 88.9%.
- Hard negatives at threshold 0.5: 3/40 false positives.
- Hard negatives at runtime threshold 0.985: 2/40 false positives (PNG evaluation).
- Real tracker batch-scoring interface passed on all 89 held-out patches. With its JPEG serialization, true-center ranking remained 47/49; 40/49 ball centers exceeded 0.985; 1/40 false candidates exceeded 0.985. The remaining JPEG false candidate is sample 305, a racket fragment.
- 41 training/review/recovery/physical-guard unit tests passed. These tests establish interface/guard behavior, not model tracking accuracy.
- Windows PowerShell logged the DirectML unsupported BCE operator warning as NativeCommandError and returned a shell status of 1. Python completed every epoch, saved the checkpoint/reports, and the independent runtime scorer loaded it successfully; the warning is CPU operator fallback, not a failed training run.
- Checkpoint SHA-256: affcdb082ab4f8b6f676cabaa9d58a8a82ef3ee3ea8e6f8d19dba6e87c7059b3.

The full 0?27920 night-video regression has NOT been run for this checkpoint, and it is NOT promoted to the runtime default. Confidence alone still accepts racket fragments, so temporal/player/motion guards remain necessary.
